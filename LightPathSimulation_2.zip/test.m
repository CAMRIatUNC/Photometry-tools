clear all
[EV_ex,index_ex,st_ex,wt_ex,xt_ex,yt_ex,zt_ex,wt2_ex,xt2_ex,yt2_ex,zt2_ex,index_4_1D_ex,stt2]=excitation(488);
save ex_488
for nm=488:700
[index_em,st_em,st_sep_ex,st_sep_em,EV_sep_ex,EV_sep_em]=emission(nm,wt2_ex,xt2_ex,yt2_ex,zt2_ex,index_4_1D_ex,stt2);
name=num2str(nm);
save(name,'index_em','st_em','st_sep_ex','st_sep_em','EV_sep_ex','EV_sep_em')
end