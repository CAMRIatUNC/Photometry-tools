function [index,st,st_sep_ex,st_sep_em,EV_sep_ex,EV_sep_em]=emission(nm,wt2_ex,xt2_ex,yt2_ex,zt2_ex,index_4_1D_ex,stt2)

close all
clc

format long

NA=0.39;
radius=0.01; % fiber tip r
tissue = makeTissueList(nm); % also --> global tissue(1:Nt).s
Nt = length(tissue);
for i=1:Nt
muav(i)  = tissue(i).mua;
musv(i)  = tissue(i).mus;
gv(i)    = tissue(i).g;
end
type=7;
ua=muav(type);
us=musv(type);
g=gv(type);
ut=ua+us;

repetitions=500000;
st=zeros(1,repetitions);
st_sep_ex=zeros(1,repetitions);
st_sep_em=zeros(1,repetitions);
index=zeros(1,repetitions);
EV_sep_ex=zeros(1,repetitions);
EV_sep_em=zeros(1,repetitions);

parfor i=1:repetitions
disp(i)
% === def starting point & angle ===
				costheta = 1 - 2*rand;
				sintheta = sqrt(1 - costheta*costheta);
				psi = 2*pi*rand;
				cospsi = cos(psi);
				if (psi < pi)
					sinpsi = sqrt(1 - cospsi*cospsi); 
				else
					sinpsi = -sqrt(1 - cospsi*cospsi);
                end
				ux = sintheta*cospsi;
				uy = sintheta*sinpsi;
				uz = costheta;
% ===
                
stemp=0;
%w=1;

GCaMP = 0;
while GCaMP == 0
em_point=randi([1 length(wt2_ex)]);
w=wt2_ex(em_point);
x=xt2_ex(em_point);
y=yt2_ex(em_point);
z=zt2_ex(em_point);
if sqrt(x^2+y^2+(z-0.03)^2) < 0.1
    GCaMP=1;
end
end

wtemp=w;
xtemp=x;
ytemp=y;
ztemp=z;

while w>0.0001 % && z~=0 && sqrt(x^2+y^2)>0.1^2

s=-log(rand)./ut;
stemp=stemp+s;

x=x+ux.*s;
y=y+uy.*s;
z=z+uz.*s;

wtemp=[wtemp w];
xtemp=[xtemp x];
ytemp=[ytemp y];
ztemp=[ztemp z];

dw=w.*(1-exp(-ua.*s));
w=w-dw;
    
if g~=0
    %costheta=1./(2.*g).*(1+g.^2-((1-g.^2)/(1-g+2.*g.*rand)).^2);
    temp = (1.0 - g*g)/(1.0 - g + 2*g*rand);
	costheta = (1.0 + g*g - temp*temp)/(2.0*g);
else
    costheta=1-2.*rand;
end
sintheta = sqrt(1-costheta.*costheta);

fi=2.*pi.*rand;
sinfi = sin(fi);
cosfi = cos(fi);

if 1 - abs(uz) <= 1.0E-12 && uz > 0
   uxx = sintheta*cosfi;
   uyy = sintheta*sinfi;
   uzz = costheta;
elseif 1 - abs(uz) <= 1.0E-12 && uz < 0
   uxx = sintheta*cosfi;
   uyy = sintheta*sinfi;
   uzz = -costheta;
else
    temp = sqrt(1.0 - uz * uz);
    uxx = sintheta * (ux * uz * cosfi - uy * sinfi) / temp + ux * costheta;
    uyy = sintheta * (uy * uz * cosfi + ux * sinfi) / temp + uy * costheta;
    uzz = -sintheta * cosfi * temp + uz * costheta;
end

ux=uxx;
uy=uyy;
uz=uzz;

if z <= 0 && abs(z) <= s && x^2+y^2 < radius^2 && uz > cos(asin(NA/1.36))
    st(i)=(sum(stt2(em_point-index_4_1D_ex(em_point)+1:em_point))+stemp)*w;
    st_sep_ex(i)=(sum(stt2(em_point-index_4_1D_ex(em_point)+1:em_point)))*wt2_ex(em_point);
    st_sep_em(i)=stemp*w;
    index(i)=1;
    EV_sep_ex(i)=wt2_ex(em_point);
    EV_sep_em(i)=w;
%     xt{i}=xtemp;
%     yt{i}=ytemp;
%     zt{i}=ztemp;
    w=0; % kill photon
elseif abs(x) > 0.4 || abs(y) > 0.4 || abs(z) > 0.4
    w=0;
end

% if w < 0.0001
%     wt{i,1}=wt2_ex(round(em_point-index_4_1D_ex(em_point)+1:em_point));
%     xt{i,1}=xt2_ex(round(em_point-index_4_1D_ex(em_point)+1:em_point));
%     yt{i,1}=yt2_ex(round(em_point-index_4_1D_ex(em_point)+1:em_point));
%     zt{i,1}=zt2_ex(round(em_point-index_4_1D_ex(em_point)+1:em_point));
%     wt{i,2}=wtemp;
%     xt{i,2}=xtemp;
%     yt{i,2}=ytemp;
%     zt{i,2}=ztemp;
% end
    
end

% % for power graph
% xt{i}=xtemp;
% %xt2=[xt2,xtemp];
% yt{i}=ytemp;
% %yt2=[yt2,ytemp];
% zt{i}=ztemp;
% %zt2=[zt2,ztemp];
% st(i)=stemp;
end

%% for path graph
% figure;
% hold on
% for i=index
% plot3(xt{i,1},yt{i,1},zt{i,1},'Color','b');
% plot3(xt{i,2},yt{i,2},zt{i,2},'Color','g');
% end
%% for power graph

% clc
% index_4_1D=[];
% wt2=[];
% for i=1:length(wt)
% wt2=[wt2,wt{i}];
% index_4_1D=[index_4_1D,1:length(cell2mat(wt{i}))];
% end
% xt2=[];
% for i=1:length(xt)
% xt2=[xt2,xt{i}];
% end
% yt2=[];
% for i=1:length(yt)
% yt2=[yt2,yt{i}];
% end
% zt2=[];
% for i=1:length(zt)
% zt2=[zt2,zt{i}];
% end
% 
% figure;
% histogram2(xt2,yt2,[-0.2:0.001:0.2],[-0.2:0.001:0.2],'DisplayStyle','tile','ShowEmptyBins','on');
% figure;
% histogram2(xt2,zt2,[-0.2:0.001:0.2],[-0.2:0.001:0.2],'DisplayStyle','tile','ShowEmptyBins','on');
% figure;
% histogram2(yt2,zt2,[-0.2:0.001:0.2],[-0.2:0.001:0.2],'DisplayStyle','tile','ShowEmptyBins','on');