x=[];
for nm = 405:700
    load([num2str(nm),'.mat'],'st_em');
    x(nm) = mean(st_em);
end
save('results.mat','x');

