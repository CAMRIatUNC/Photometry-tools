function [EV,index,st,wt,xt,yt,zt,wt2,xt2,yt2,zt2,index_4_1D,stt2]=excitation(nm)

close all
clc

format long

%nm=400;
NA=0.39;
tissue = makeTissueList(nm); % also --> global tissue(1:Nt).s
Nt = length(tissue);
for i=1:Nt
muav(i)  = tissue(i).mua;
musv(i)  = tissue(i).mus;
gv(i)    = tissue(i).g;
end
type=7;
ua=muav(type);
us=musv(type);
g=gv(type);
ut=ua+us;
st=[];
index=[];
EV=[];
% xt2=[];
% yt2=[];
% zt2=[];

stt=cell(1,10000);
wt=cell(1,10000);
xt=cell(1,10000);
yt=cell(1,10000);
zt=cell(1,10000);

parfor i=1:10000
disp(i)
% === def starting point & angle ===
% def starting point
radius=0.01; %cm
r = radius*sqrt(rand);
phi = rand*2.0*pi;
x = r*cos(phi);
y = r*sin(phi);
z=0;

% def starting angle
r_focus = sqrt(rand);
phi_focus = rand*2.0*pi;
xfocus = x+r_focus*cos(phi_focus);
yfocus = y+r_focus*sin(phi_focus);
zfocus = 1/tan(asin(NA/1.36)); % NA_fiber/N_rat_brain(1.36)
% NA_fiber = N_rat_brain*sin(theta)
% theta = asin(NA/1,36) && tan(theta) = 1/zfocus
% -> zfocus = 1/tan(asin(NA/1.36))

% Normalize starting vector to unit vector
temp = sqrt((x - xfocus)^2 + (y - yfocus)^2 + (z - zfocus)^2);
ux = -(x - xfocus)/temp;
uy = -(y - yfocus)/temp;
uz = -sqrt(1 - ux*ux - uy*uy);

w=1;
stemp=0;
wtemp=w;
xtemp=x;
ytemp=y;
ztemp=z;

while w>0.0001 % && z~=0 && sqrt(x^2+y^2)>0.1^2

s=-log(rand)./ut;
stemp=[stemp s];

x=x+ux.*s;
y=y+uy.*s;
z=z+uz.*s;

wtemp=[wtemp w];
xtemp=[xtemp x];
ytemp=[ytemp y];
ztemp=[ztemp z];

dw=w.*(1-exp(-ua.*s));
w=w-dw;
    
if g~=0
    %costheta=1./(2.*g).*(1+g.^2-((1-g.^2)/(1-g+2.*g.*rand)).^2);
    temp = (1.0 - g*g)/(1.0 - g + 2*g*rand);
	costheta = (1.0 + g*g - temp*temp)/(2.0*g);
else
    costheta=1-2.*rand;
end
sintheta = sqrt(1-costheta.*costheta);

fi=2.*pi.*rand;
sinfi = sin(fi);
cosfi = cos(fi);

if 1 - abs(uz) <= 1.0E-12 && uz > 0
   uxx = sintheta*cosfi;
   uyy = sintheta*sinfi;
   uzz = costheta;
elseif 1 - abs(uz) <= 1.0E-12 && uz < 0
   uxx = sintheta*cosfi;
   uyy = sintheta*sinfi;
   uzz = -costheta;
else
    temp = sqrt(1.0 - uz * uz);
    uxx = sintheta * (ux * uz * cosfi - uy * sinfi) / temp + ux * costheta;
    uyy = sintheta * (uy * uz * cosfi + ux * sinfi) / temp + uy * costheta;
    uzz = -sintheta * cosfi * temp + uz * costheta;
end

ux=uxx;
uy=uyy;
uz=uzz;

if z <= 0 && abs(z) <= s && x^2+y^2 < radius^2 && uz > cos(asin(NA/1.36))
%     st=[st sum(stemp')*w];
%     index=[index i];
%     EV=[EV w];
%     xt{i}=xtemp;
%     yt{i}=ytemp;
%     zt{i}=ztemp;
    w=0; % kill photon
elseif abs(x) > 0.4 || abs(y) > 0.4 || abs(z) > 0.4
%elseif sqrt(x^2+y^2+(z-0.03)^2) > 0.1
    w=0;
end

if w < 0.0001
    stt{i}=stemp;
    wt{i}=wtemp;
    xt{i}=xtemp;
    yt{i}=ytemp;
    zt{i}=ztemp;
end
    
end

% % for power graph
% xt{i}=xtemp;
% %xt2=[xt2,xtemp];
% yt{i}=ytemp;
% %yt2=[yt2,ytemp];
% zt{i}=ztemp;
% %zt2=[zt2,ztemp];
% st(i)=stemp;
end

%% for path graph
% for i=index
% plot3(xt{i},yt{i},zt{i});
% hold on
% end

%% for power graph

clc
CellSize=cellfun(@length,stt);
TotalDataLength=sum(CellSize);
wt2=zeros(1,TotalDataLength);
index_4_1D=zeros(1,TotalDataLength);
stt2=zeros(1,TotalDataLength);
xt2=zeros(1,TotalDataLength);
yt2=zeros(1,TotalDataLength);
zt2=zeros(1,TotalDataLength);
for i=1:10000
disp(i)
if i==1
range=1:CellSize(i);
else
range=[1:CellSize(i)]+sum(CellSize(1:i-1));
end
wt2(range)=wt{i};
index_4_1D(range)=1:CellSize(i);
stt2(range)=stt{i};
xt2(range)=xt{i};
yt2(range)=yt{i};
zt2(range)=zt{i};
end

% figure;
% histogram2(xt2,yt2,[-0.2:0.001:0.2],[-0.2:0.001:0.2],'DisplayStyle','tile','ShowEmptyBins','on');
% figure;
% histogram2(xt2,zt2,[-0.2:0.001:0.2],[-0.2:0.001:0.2],'DisplayStyle','tile','ShowEmptyBins','on');
% figure;
% histogram2(yt2,zt2,[-0.2:0.001:0.2],[-0.2:0.001:0.2],'DisplayStyle','tile','ShowEmptyBins','on');